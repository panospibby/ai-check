# AI image detection upgrade

- Preserves the original Detectra v3 / ONNX architecture and floating region selector.
- Increases screen capture width from 1080px to 1440px when the device supports it.
- Still-image detection now uses five spatial crops (center + four corners) and the median AI probability.
- Median spatial ensembling reduces sensitivity to a single misleading crop and improves portrait/landscape coverage.
- Video keeps the fast single-crop image inference per frame because video already aggregates 8 temporal frames.
- Original 65% Detectra threshold is preserved to avoid uncalibrated threshold changes.
