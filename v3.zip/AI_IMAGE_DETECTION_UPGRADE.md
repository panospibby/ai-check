# AI Screen Check 7.0 — Conservative Hybrid Forensics

This version intentionally does **not** promise 100% AI detection. No current detector can do that reliably across unknown generators, editing, compression, screenshots, mixed human/AI work, and adversarial transformations.

The v7 design instead minimizes confident mistakes by combining independent signals and abstaining when they disagree.

## Image
- Detectra / Community Forensics model.
- PE-Small 2026 Perception Encoder model (different model family).
- Optional Sightengine cloud verification.
- High-confidence AI/REAL requires strong agreement; otherwise the result is `ΑΒΕΒΑΙΟ`.
- The result card shows each detector's individual AI score.

## Video
- 8 temporal frames from the user-selected region.
- Both Detectra and PE-Small analyze the frames.
- Per-model temporal medians are combined with the same conservative consensus policy.

## Music
- ArtifactNet v9.4 on multiple 4-second 44.1 kHz segments.
- Optional Sightengine AI-music verification.
- A single model only gives a high-confidence verdict at an extreme score; otherwise the app abstains.

## Text
- Local DistilBERT detector for English.
- Optional Copyleaks verification.
- If the local model does not support the text/language, cloud-only results use a stricter confidence gate.

## Decision policy
- Two signals: both must be strongly AI (>=80%) or strongly real (<=20%) for a high-confidence verdict.
- One signal: only extreme >=92% AI or <=8% AI receives a high-confidence verdict.
- Three signals: at least two must strongly agree and none may strongly vote the opposite direction.
- Extreme contradictions always produce `ΑΒΕΒΑΙΟ`.

## Models / licenses
- Detectra / Community Forensics: see upstream model license.
- Deckard18 PE-Small: CC BY-NC 4.0 (non-commercial model use).
- ArtifactNet v9.4: CC BY-NC 4.0 (non-commercial model use; upstream also notes patent restrictions for commercial deployment).
- Local text model: see upstream Hugging Face model license.

This patch is intended for personal/research evaluation unless all upstream model licenses are separately cleared for another use.
