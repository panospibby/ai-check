package com.panos.aiscreencheck;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 1001;
    private static final int REQ_NOTIFICATIONS = 1002;
    private static final int REQ_AUDIO = 1003;

    private MediaProjectionManager projectionManager;
    private TextView status;
    private Button startButton;
    private boolean pendingStartAfterAudioPermission = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        buildUi();
        requestNotificationPermissionIfNeeded();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshState();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(34), dp(24), dp(34));
        root.setBackgroundColor(0xFF0F1115);
        scroll.addView(root);

        TextView title = text("AI Screen Check 6.0", 30, 0xFFFFFFFF);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        TextView badge = text("ON-DEVICE MODELS • ΧΩΡΙΣ API", 13, 0xFF8AB4F8);
        badge.setTypeface(null, android.graphics.Typeface.BOLD);
        badge.setPadding(0, dp(8), 0, dp(20));
        root.addView(badge);

        TextView subtitle = text(
                "Ξεκίνα το floating AI και μετά διάλεξε τι θέλεις να ελέγξεις: Εικόνα, Video, Μουσική ή Κείμενο.",
                17, 0xFFD5D8DE);
        subtitle.setPadding(0, 0, 0, dp(26));
        root.addView(subtitle);

        startButton = button("START FLOATING AI", 22);
        startButton.setMinHeight(dp(78));
        startButton.setOnClickListener(v -> onStartPressed());
        root.addView(startButton, fullWidth(dp(14)));

        status = text("Έτοιμο.", 15, 0xFF9CC2FF);
        status.setPadding(dp(4), dp(4), dp(4), dp(22));
        root.addView(status);

        TextView how = text(
                "ΧΡΗΣΗ\n\n" +
                "• Θα βλέπεις μόνο ένα μικρό AI κυκλάκι στην άκρη της οθόνης.\n" +
                "• Tap στο κυκλάκι → ΕΙΚΟΝΑ / VIDEO / ΜΟΥΣΙΚΗ / ΚΕΙΜΕΝΟ / ΚΛΕΙΣΙΜΟ.\n" +
                "• Σε Εικόνα/Video σύρε πλαίσιο ΑΚΡΙΒΩΣ γύρω από το περιεχόμενο. Έτσι δεν αναλύονται τα κουμπιά/μαύρα περιθώρια της εφαρμογής.\n" +
                "• Το αποτέλεσμα εμφανίζεται σε μικρή κάρτα στην άκρη και κλείνει μόνο του.\n\n" +
                "Εικόνα/Video: Detectra v3 (Community Forensics) πάνω μόνο στην επιλεγμένη περιοχή.\n" +
                "Μουσική: ONNX spectral-fingerprint detector, καλύτερα με 10+ sec καθαρού ήχου.\n" +
                "Κείμενο: trained DistilBERT detector για αγγλικά. Για ελληνικά δεν βγάζει ψεύτικο score.",
                15, 0xFFB7BBC3);
        how.setPadding(0, dp(8), 0, dp(24));
        root.addView(how);

        Button showMenu = button("Άνοιγμα floating menu", 16);
        showMenu.setOnClickListener(v -> {
            if (!CaptureService.isRunning()) {
                Toast.makeText(this, "Πρώτα ξεκίνα το floating AI.", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent i = new Intent(this, CaptureService.class);
            i.setAction(CaptureService.ACTION_SHOW_MENU);
            startService(i);
        });
        root.addView(showMenu, fullWidth(dp(10)));

        Button stop = button("STOP & CLOSE", 16);
        stop.setOnClickListener(v -> stopAndClose());
        root.addView(stop, fullWidth(0));

        TextView disclaimer = text(
                "Το ποσοστό εικόνας/video είναι το πραγματικό sigmoid score του Detectra v3 πάνω στην περιοχή που επιλέγεις. Verdict AI από 65% και πάνω. Κανένας detector δεν είναι αλάνθαστος· χρησιμοποίησέ το ως ένδειξη, όχι απόδειξη.",
                12, 0xFF7F858F);
        disclaimer.setPadding(0, dp(22), 0, 0);
        root.addView(disclaimer);

        setContentView(scroll);
    }

    private void refreshState() {
        if (status == null || startButton == null) return;
        if (CaptureService.isRunning()) {
            startButton.setText("OPEN FLOATING MENU");
            status.setText("Ενεργό. Το AI bubble είναι στην άκρη της οθόνης.");
        } else {
            startButton.setText("START FLOATING AI");
            status.setText("Έτοιμο.");
        }
    }

    private void onStartPressed() {
        if (CaptureService.isRunning()) {
            Intent i = new Intent(this, CaptureService.class);
            i.setAction(CaptureService.ACTION_SHOW_MENU);
            startService(i);
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            status.setText("Ενεργοποίησε «Εμφάνιση πάνω από άλλες εφαρμογές» και γύρνα εδώ.");
            startActivity(new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }

        if (Build.VERSION.SDK_INT >= 29
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingStartAfterAudioPermission = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        requestScreenCapture();
    }

    private void requestScreenCapture() {
        status.setText("Δώσε άδεια καταγραφής οθόνης. Μετά μπορείς να χειρίζεσαι κανονικά το κινητό.");
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    private void stopAndClose() {
        Intent stop = new Intent(this, CaptureService.class);
        stop.setAction(CaptureService.ACTION_STOP);
        try { startService(stop); } catch (Exception ignored) {}
        Toast.makeText(this, "AI Screen Check έκλεισε", Toast.LENGTH_SHORT).show();
        if (Build.VERSION.SDK_INT >= 21) finishAndRemoveTask();
        else finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            status.setText("Η άδεια Screen Capture ακυρώθηκε.");
            return;
        }

        Intent service = new Intent(this, CaptureService.class);
        service.putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode);
        service.putExtra(CaptureService.EXTRA_RESULT_DATA, data);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
        else startService(service);

        status.setText("Ενεργό. Άνοιξε TikTok / Instagram / browser και πάτησε το AI bubble.");
        Toast.makeText(this, "Floating AI ενεργό", Toast.LENGTH_SHORT).show();
        refreshState();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO && pendingStartAfterAudioPermission) {
            pendingStartAfterAudioPermission = false;
            requestScreenCapture();
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    private Button button(String label, int sp) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(sp);
        b.setAllCaps(false);
        b.setTypeface(null, android.graphics.Typeface.BOLD);
        return b;
    }

    private LinearLayout.LayoutParams fullWidth(int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, bottom);
        return lp;
    }

    private TextView text(String value, int sp, int color) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setGravity(Gravity.START);
        tv.setLineSpacing(0f, 1.08f);
        return tv;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
