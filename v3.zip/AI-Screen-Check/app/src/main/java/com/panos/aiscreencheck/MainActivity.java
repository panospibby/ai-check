package com.panos.aiscreencheck;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 1001;
    private static final int REQ_NOTIFICATIONS = 1002;
    private static final int REQ_AUDIO = 1003;

    private MediaProjectionManager projectionManager;
    private TextView status;
    private Button mainButton;
    private boolean pendingStartAfterAudioPermission = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        buildUi();
        requestNotificationPermissionIfNeeded();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (status == null || mainButton == null) return;
        if (CaptureService.isRunning()) {
            mainButton.setText("AI CHECK");
            status.setText("Ενεργό • πάτησε AI CHECK εδώ ή το floating AI κυκλάκι.");
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            status.setText("Πρώτη χρήση: πάτησε AI CHECK και δώσε άδεια εμφάνισης πάνω από άλλες εφαρμογές.");
        } else {
            status.setText("Έτοιμο. Ένα κουμπί για κείμενο, εικόνα/video και μουσική.");
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(34), dp(24), dp(34));
        root.setBackgroundColor(0xFF0F1115);
        scroll.addView(root);

        TextView title = text("AI Screen Check 3.0", 30, 0xFFFFFFFF);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        TextView badge = text("LOCAL • ΧΩΡΙΣ API • ΧΩΡΙΣ ΣΥΝΔΡΟΜΗ", 13, 0xFF8AB4F8);
        badge.setTypeface(null, android.graphics.Typeface.BOLD);
        badge.setPadding(0, dp(8), 0, dp(18));
        root.addView(badge);

        TextView subtitle = text(
                "Ένα tap κάνει SMART έλεγχο του περιεχομένου που βλέπεις: ορατό κείμενο, εικόνα, video frames και μουσική/ήχο.",
                17, 0xFFD5D8DE);
        subtitle.setPadding(0, 0, 0, dp(28));
        root.addView(subtitle);

        mainButton = new Button(this);
        mainButton.setText("AI CHECK");
        mainButton.setTextSize(23);
        mainButton.setAllCaps(false);
        mainButton.setTypeface(null, android.graphics.Typeface.BOLD);
        mainButton.setMinHeight(dp(82));
        mainButton.setOnClickListener(v -> onAiCheckPressed());
        LinearLayout.LayoutParams big = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        big.setMargins(0, 0, 0, dp(16));
        root.addView(mainButton, big);

        status = text("Έτοιμο.", 15, 0xFF9CC2FF);
        status.setPadding(dp(4), dp(6), dp(4), dp(22));
        root.addView(status);

        TextView how = text(
                "ΠΩΣ ΔΟΥΛΕΥΕΙ\n\n" +
                "1. Πάτησε AI CHECK. Στην πρώτη χρήση το Android θα ζητήσει τις απαραίτητες άδειες.\n\n" +
                "2. Εμφανίζεται ένα μικρό floating κυκλάκι AI πάνω από TikTok, Instagram, browser κ.λπ.\n\n" +
                "3. Ένα tap στο κυκλάκι ελέγχει αυτόματα Κείμενο • Εικόνα • Video • Μουσική και δείχνει ποσοστό πιθανότητας AI.\n\n" +
                "Οι έλεγχοι γίνονται τοπικά στη συσκευή. Δεν στέλνονται screenshots, κείμενα ή ήχος σε Sightengine/Copyleaks.",
                15, 0xFFB7BBC3);
        how.setPadding(0, dp(8), 0, dp(24));
        root.addView(how);

        Button stop = new Button(this);
        stop.setText("Stop floating AI Check");
        stop.setAllCaps(false);
        stop.setOnClickListener(v -> stopServiceNow());
        root.addView(stop, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView disclaimer = text(
                "Σημείωση: κανένας detector δεν μπορεί να αποδείξει με βεβαιότητα ότι κάτι είναι AI. Τα ποσοστά είναι ενδείξεις και ειδικά για σύντομο κείμενο ή heavily-compressed media η βεβαιότητα είναι χαμηλότερη.",
                12, 0xFF7F858F);
        disclaimer.setPadding(0, dp(24), 0, 0);
        root.addView(disclaimer);

        setContentView(scroll);
    }

    private void onAiCheckPressed() {
        if (CaptureService.isRunning()) {
            Intent scan = new Intent(this, CaptureService.class);
            scan.setAction(CaptureService.ACTION_SMART_SCAN);
            startService(scan);
            status.setText("SMART scan…");
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            status.setText("Ενεργοποίησε «Εμφάνιση πάνω από άλλες εφαρμογές» και γύρνα εδώ.");
            Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            return;
        }

        if (Build.VERSION.SDK_INT >= 29
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingStartAfterAudioPermission = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }

        requestScreenCapture();
    }

    private void requestScreenCapture() {
        status.setText("Δώσε άδεια για προβολή/καταγραφή της οθόνης…");
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    private void stopServiceNow() {
        Intent stop = new Intent(this, CaptureService.class);
        stop.setAction(CaptureService.ACTION_STOP);
        startService(stop);
        status.setText("Σταματημένο.");
        mainButton.setText("AI CHECK");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;

        if (resultCode != RESULT_OK || data == null) {
            status.setText("Η άδεια Screen Capture ακυρώθηκε.");
            return;
        }

        Intent service = new Intent(this, CaptureService.class);
        service.putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode);
        service.putExtra(CaptureService.EXTRA_RESULT_DATA, data);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
        else startService(service);

        mainButton.setText("AI CHECK");
        status.setText("Ενεργό • άνοιξε οποιαδήποτε εφαρμογή και πάτησε το floating AI.");
        Toast.makeText(this, "AI Screen Check ενεργό", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO && pendingStartAfterAudioPermission) {
            pendingStartAfterAudioPermission = false;
            // Even if audio permission was denied, continue. Image/text/video can still work.
            requestScreenCapture();
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    private TextView text(String value, int sp, int color) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setGravity(Gravity.START);
        tv.setLineSpacing(0f, 1.08f);
        return tv;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
