package com.panos.aiscreencheck;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;

import org.jtransforms.fft.FloatFFT_1D;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.FloatBuffer;
import java.nio.LongBuffer;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

final class OnDeviceModels implements AutoCloseable {
    // Conservative v7 policy: the app may abstain instead of forcing a wrong binary answer.
    static final double STRONG_AI = 0.80;
    static final double STRONG_REAL = 0.20;
    static final double VERY_STRONG_AI = 0.92;
    static final double VERY_STRONG_REAL = 0.08;

    private final Context context;
    private final OrtEnvironment env;
    private OrtSession imageSession;
    private OrtSession peSession;
    private OrtSession artifactSession;
    private OrtSession textSession;
    private BertTokenizer tokenizer;

    OnDeviceModels(Context context) {
        this.context = context.getApplicationContext();
        this.env = OrtEnvironment.getEnvironment();
    }

    /**
     * Local image forensic ensemble. The two signals are intentionally different:
     * Detectra/Community-Forensics and a Perception-Encoder classifier. A single
     * detector is never allowed to produce a confident VERIFIED verdict by itself.
     */
    synchronized DetectionResult image(Bitmap source) throws Exception {
        return imageInternal(source, true);
    }

    /** Fast path used by video. Both independent model families are still used. */
    synchronized DetectionResult imageFast(Bitmap source) throws Exception {
        return imageInternal(source, false);
    }

    private DetectionResult imageInternal(Bitmap source, boolean spatialEnsemble) throws Exception {
        if (source == null || source.isRecycled()) return DetectionResult.unavailable("Δεν υπάρχει εικόνα");
        if (source.getWidth() < 64 || source.getHeight() < 64) {
            return DetectionResult.unavailable("Η εικόνα είναι πολύ μικρή");
        }
        if (imageSession == null) imageSession = createSession("models/detectra_image.onnx");
        if (peSession == null) peSession = createSession("models/pe_small_image.onnx");

        List<Signal> signals = new ArrayList<>();
        signals.add(new Signal("Detectra", detectraScore(source, spatialEnsemble)));
        signals.add(new Signal("PE-Small 2026", peScore(source)));
        return DetectionResult.consensus("Εικόνα", signals,
                spatialEnsemble ? "2 independent models + spatial robustness" : "2 independent models");
    }

    private double detectraScore(Bitmap source, boolean spatialEnsemble) throws Exception {
        final int target = 384;
        final int resizeShort = 440;
        int sw = source.getWidth();
        int sh = source.getHeight();
        float scale = resizeShort / (float) Math.min(sw, sh);
        int rw = Math.max(target, Math.round(sw * scale));
        int rh = Math.max(target, Math.round(sh * scale));
        Bitmap resized = Bitmap.createScaledBitmap(source, rw, rh, true);
        try {
            int maxX = Math.max(0, rw - target);
            int maxY = Math.max(0, rh - target);
            int cx = maxX / 2;
            int cy = maxY / 2;
            List<Double> scores = new ArrayList<>();
            scores.add(scoreDetectraCrop(resized, cx, cy, target));
            if (spatialEnsemble) {
                // Three views are enough here; model-family diversity matters more than
                // repeating the same model five times.
                addDetectraCrop(scores, resized, 0, 0, target, cx, cy);
                addDetectraCrop(scores, resized, maxX, maxY, target, cx, cy);
            }
            return median(scores);
        } finally {
            if (resized != source && !resized.isRecycled()) resized.recycle();
        }
    }

    private void addDetectraCrop(List<Double> scores, Bitmap resized, int x, int y,
                                 int target, int cx, int cy) throws Exception {
        if (x == cx && y == cy) return;
        scores.add(scoreDetectraCrop(resized, x, y, target));
    }

    private double scoreDetectraCrop(Bitmap resized, int left, int top, int target) throws Exception {
        left = Math.max(0, Math.min(left, resized.getWidth() - target));
        top = Math.max(0, Math.min(top, resized.getHeight() - target));
        Bitmap crop = Bitmap.createBitmap(resized, left, top, target, target);
        try {
            float[] data = imageTensor(crop, target,
                    new float[]{0.485f, 0.456f, 0.406f},
                    new float[]{0.229f, 0.224f, 0.225f}, true);
            String inputName = imageSession.getInputNames().contains("pixel_values")
                    ? "pixel_values" : imageSession.getInputNames().iterator().next();
            try (OnnxTensor input = OnnxTensor.createTensor(env, FloatBuffer.wrap(data), new long[]{1, 3, target, target});
                 OrtSession.Result out = imageSession.run(Map.of(inputName, input))) {
                float[] values = flattenFloats(out.get(0).getValue());
                if (values.length < 1) throw new IllegalStateException("Detectra output invalid");
                return sigmoid(values[0]);
            }
        } finally {
            if (!crop.isRecycled()) crop.recycle();
        }
    }

    /** PE model: short side 256, center crop 256, RGB [0,1], logits [fake, real]. */
    private double peScore(Bitmap source) throws Exception {
        final int target = 256;
        int sw = source.getWidth(), sh = source.getHeight();
        float scale = target / (float) Math.min(sw, sh);
        int rw = Math.max(target, Math.round(sw * scale));
        int rh = Math.max(target, Math.round(sh * scale));
        Bitmap resized = Bitmap.createScaledBitmap(source, rw, rh, true);
        Bitmap crop = Bitmap.createBitmap(resized, Math.max(0, (rw - target) / 2),
                Math.max(0, (rh - target) / 2), target, target);
        try {
            float[] data = imageTensor(crop, target, null, null, false);
            String inputName = peSession.getInputNames().iterator().next();
            try (OnnxTensor input = OnnxTensor.createTensor(env, FloatBuffer.wrap(data), new long[]{1, 3, target, target});
                 OrtSession.Result out = peSession.run(Map.of(inputName, input))) {
                float[] logits = flattenFloats(out.get(0).getValue());
                if (logits.length < 2) throw new IllegalStateException("PE image output invalid");
                // model labels are [fake, real]
                return softmaxFirst(logits[0], logits[1]);
            }
        } finally {
            if (!crop.isRecycled()) crop.recycle();
            if (resized != source && !resized.isRecycled()) resized.recycle();
        }
    }

    private static float[] imageTensor(Bitmap bmp, int target, float[] mean, float[] std, boolean normalize) {
        int[] px = new int[target * target];
        bmp.getPixels(px, 0, target, 0, 0, target, target);
        float[] data = new float[3 * target * target];
        int plane = target * target;
        for (int i = 0; i < px.length; i++) {
            int c = px[i];
            float r = Color.red(c) / 255f;
            float g = Color.green(c) / 255f;
            float b = Color.blue(c) / 255f;
            if (normalize) {
                r = (r - mean[0]) / std[0];
                g = (g - mean[1]) / std[1];
                b = (b - mean[2]) / std[2];
            }
            data[i] = r;
            data[plane + i] = g;
            data[2 * plane + i] = b;
        }
        return data;
    }

    synchronized DetectionResult text(String inputText) throws Exception {
        String text = inputText == null ? "" : inputText.replaceAll("\\s+", " ").trim();
        if (text.length() < 120) {
            return DetectionResult.unavailable("Χρειάζονται τουλάχιστον ~120 χαρακτήρες");
        }
        if (!looksEnglish(text)) {
            return DetectionResult.unavailable("Το trained text model αυτής της έκδοσης υποστηρίζει αγγλικά");
        }
        if (textSession == null) textSession = createSession("models/text_detector.onnx");
        if (tokenizer == null) tokenizer = new BertTokenizer(context, "models/vocab.txt");

        BertTokenizer.Encoding enc = tokenizer.encode(text, 256);
        Map<String, OnnxTensor> feeds = new HashMap<>();
        try (OnnxTensor ids = OnnxTensor.createTensor(env, LongBuffer.wrap(enc.inputIds), new long[]{1, enc.inputIds.length});
             OnnxTensor mask = OnnxTensor.createTensor(env, LongBuffer.wrap(enc.attentionMask), new long[]{1, enc.attentionMask.length})) {
            feeds.put("input_ids", ids);
            feeds.put("attention_mask", mask);
            try (OrtSession.Result out = textSession.run(feeds)) {
                float[] logits = flattenFloats(out.get(0).getValue());
                if (logits.length < 2) throw new IllegalStateException("Text model output invalid");
                double pAi = softmaxSecond(logits[0], logits[1]);
                List<Signal> signals = new ArrayList<>();
                signals.add(new Signal("Local DistilBERT", pAi));
                return DetectionResult.single("Κείμενο", signals.get(0),
                        "Local English text detector");
            }
        }
    }

    synchronized DetectionResult music(short[] samples, int count, int sampleRate) throws Exception {
        if (sampleRate != 44100) return DetectionResult.unavailable("Απαιτεί 44.1 kHz capture");
        if (count < sampleRate * 4) return DetectionResult.unavailable("Χρειάζονται τουλάχιστον 4 δευτερόλεπτα ήχου");
        if (rms(samples, count) < 0.0035) return DetectionResult.unavailable("Δεν ανιχνεύτηκε αρκετός ήχος");
        if (artifactSession == null) {
            // ArtifactNet uses an ONNX external-data sidecar. Copy it first so ORT can resolve it.
            assetToFile("models/artifactnet_v94_full.onnx.data");
            artifactSession = createSession("models/artifactnet_v94_full.onnx");
        }

        final int chunk = 4 * sampleRate;
        List<Double> segmentScores = new ArrayList<>();
        int[] starts;
        if (count >= chunk * 3) starts = new int[]{0, (count - chunk) / 2, count - chunk};
        else if (count >= chunk * 2) starts = new int[]{0, count - chunk};
        else starts = new int[]{0};

        String inputName = artifactSession.getInputNames().contains("audio")
                ? "audio" : artifactSession.getInputNames().iterator().next();
        for (int start : starts) {
            float[] audio = new float[chunk];
            for (int i = 0; i < chunk; i++) audio[i] = samples[start + i] / 32768f;
            try (OnnxTensor input = OnnxTensor.createTensor(env, FloatBuffer.wrap(audio), new long[]{1, chunk});
                 OrtSession.Result out = artifactSession.run(Map.of(inputName, input))) {
                float[] values = flattenFloats(out.get(0).getValue());
                if (values.length < 1) throw new IllegalStateException("ArtifactNet output invalid");
                double p = values[0];
                if (p < 0.0 || p > 1.0) p = sigmoid(values[0]);
                segmentScores.add(clamp(p, 0.0, 1.0));
            }
        }
        Signal local = new Signal("ArtifactNet v9.4", median(segmentScores));
        return DetectionResult.single("Μουσική", local,
                segmentScores.size() + " x 4s forensic segments");
    }

    private OrtSession createSession(String assetName) throws Exception {
        File model = assetToFile(assetName);
        OrtSession.SessionOptions opts = new OrtSession.SessionOptions();
        opts.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT);
        opts.setIntraOpNumThreads(Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors())));
        return env.createSession(model.getAbsolutePath(), opts);
    }

    private File assetToFile(String assetName) throws Exception {
        File dir = new File(context.getFilesDir(), "models-v5");
        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cannot create model directory");
        File out = new File(dir, new File(assetName).getName());
        if (out.exists() && out.length() > 4096) return out;
        try (InputStream in = context.getAssets().open(assetName);
             FileOutputStream fos = new FileOutputStream(out)) {
            byte[] buffer = new byte[1024 * 1024];
            int n;
            while ((n = in.read(buffer)) > 0) fos.write(buffer, 0, n);
        }
        return out;
    }

    private static boolean looksEnglish(String text) {
        int letters = 0, latin = 0, greek = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (!Character.isLetter(c)) continue;
            letters++;
            Character.UnicodeBlock block = Character.UnicodeBlock.of(c);
            if (block == Character.UnicodeBlock.GREEK || block == Character.UnicodeBlock.GREEK_EXTENDED) greek++;
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) latin++;
        }
        if (letters < 25) return false;
        return greek == 0 && latin >= letters * 0.80;
    }

    private static double rms(short[] samples, int count) {
        double sum = 0.0;
        for (int i = 0; i < count; i++) {
            double v = samples[i] / 32768.0;
            sum += v * v;
        }
        return Math.sqrt(sum / Math.max(1, count));
    }

    private static float[] computeFakeprint(short[] pcm, int count, int sampleRate) {
        final int nfft = 8192;
        final int hop = nfft / 2;
        final int pad = nfft / 2;
        final int paddedLength = count + 2 * pad;
        float[] signal = new float[paddedLength];

        // Reflect padding to match torchaudio Spectrogram(center=True, pad_mode=reflect) closely.
        for (int i = 0; i < count; i++) signal[pad + i] = pcm[i] / 32768f;
        for (int i = 0; i < pad; i++) {
            int li = Math.min(count - 1, pad - i);
            int ri = Math.max(0, count - 2 - i);
            signal[i] = pcm[Math.max(0, li)] / 32768f;
            signal[pad + count + i] = pcm[Math.max(0, ri)] / 32768f;
        }

        float[] window = new float[nfft];
        for (int i = 0; i < nfft; i++) {
            window[i] = (float) (0.5 - 0.5 * Math.cos(2.0 * Math.PI * i / nfft));
        }

        int frames = Math.max(1, 1 + (paddedLength - nfft) / hop);
        int bins = nfft / 2 + 1;
        double[] meanDb = new double[bins];
        FloatFFT_1D fft = new FloatFFT_1D(nfft);
        float[] work = new float[2 * nfft];

        for (int f = 0; f < frames; f++) {
            int base = f * hop;
            java.util.Arrays.fill(work, 0f);
            for (int i = 0; i < nfft; i++) work[i] = signal[base + i] * window[i];
            fft.realForwardFull(work);
            for (int k = 0; k < bins; k++) {
                double re = work[2 * k];
                double im = work[2 * k + 1];
                double power = Math.max(1e-10, re * re + im * im);
                meanDb[k] += 10.0 * Math.log10(power);
            }
        }
        for (int k = 0; k < bins; k++) meanDb[k] /= frames;

        int start = (int) Math.ceil(1000.0 * nfft / sampleRate); // 512
        int end = Math.min(nfft / 2, (int) Math.floor(8000.0 * nfft / sampleRate)); // 4096
        int len = end - start + 1;
        float[] spectrum = new float[len];
        for (int i = 0; i < len; i++) spectrum[i] = (float) meanDb[start + i];

        float[] hull = new float[len];
        final int filterSize = 10;
        final int leftRadius = filterSize / 2;
        final int rightRadius = filterSize - leftRadius - 1;
        for (int i = 0; i < len; i++) {
            float min = Float.POSITIVE_INFINITY;
            for (int d = -leftRadius; d <= rightRadius; d++) {
                int j = Math.max(0, Math.min(len - 1, i + d));
                min = Math.min(min, spectrum[j]);
            }
            hull[i] = Math.max(-45f, min);
        }

        float max = 1e-6f;
        float[] residue = new float[len];
        for (int i = 0; i < len; i++) {
            float v = Math.max(0f, spectrum[i] - hull[i]);
            v = Math.min(5f, v);
            residue[i] = v;
            if (v > max) max = v;
        }
        for (int i = 0; i < len; i++) residue[i] /= max;
        return residue;
    }

    private static double sigmoid(float x) {
        if (x >= 0) {
            double z = Math.exp(-x);
            return 1.0 / (1.0 + z);
        }
        double z = Math.exp(x);
        return z / (1.0 + z);
    }

    private static double softmaxFirst(float a, float b) {
        double m = Math.max(a, b);
        double ea = Math.exp(a - m);
        double eb = Math.exp(b - m);
        return ea / (ea + eb);
    }

    private static double median(List<Double> values) {
        if (values == null || values.isEmpty()) return Double.NaN;
        List<Double> copy = new ArrayList<>(values);
        Collections.sort(copy);
        int n = copy.size();
        return (n & 1) == 1 ? copy.get(n / 2) : (copy.get(n / 2 - 1) + copy.get(n / 2)) / 2.0;
    }

    private static double softmaxSecond(float a, float b) {
        double m = Math.max(a, b);
        double ea = Math.exp(a - m);
        double eb = Math.exp(b - m);
        return eb / (ea + eb);
    }

    private static float[] flattenFloats(Object value) {
        if (value instanceof float[]) return (float[]) value;
        if (value instanceof float[][]) {
            float[][] a = (float[][]) value;
            return a.length == 0 ? new float[0] : a[0];
        }
        if (value instanceof double[]) {
            double[] a = (double[]) value;
            float[] r = new float[a.length];
            for (int i = 0; i < a.length; i++) r[i] = (float) a[i];
            return r;
        }
        if (value instanceof double[][]) {
            double[][] a = (double[][]) value;
            if (a.length == 0) return new float[0];
            float[] r = new float[a[0].length];
            for (int i = 0; i < r.length; i++) r[i] = (float) a[0][i];
            return r;
        }
        throw new IllegalStateException("Unsupported model output: " + value.getClass().getName());
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    @Override
    public synchronized void close() {
        try { if (imageSession != null) imageSession.close(); } catch (Exception ignored) {}
        try { if (peSession != null) peSession.close(); } catch (Exception ignored) {}
        try { if (artifactSession != null) artifactSession.close(); } catch (Exception ignored) {}
        try { if (textSession != null) textSession.close(); } catch (Exception ignored) {}
        imageSession = null;
        peSession = null;
        artifactSession = null;
        textSession = null;
    }

    enum Verdict { VERIFIED_AI, VERIFIED_REAL, UNCERTAIN }

    static final class Signal {
        final String name;
        final double aiProbability;
        Signal(String name, double aiProbability) {
            this.name = name == null ? "Model" : name;
            this.aiProbability = clamp(aiProbability, 0.0, 1.0);
        }
    }

    static final class DetectionResult {
        final boolean available;
        final double aiProbability;
        final Verdict verdict;
        final String model;
        final String type;
        final String note;
        final List<Signal> signals;

        private DetectionResult(boolean available, double aiProbability, Verdict verdict,
                                String model, String type, String note, List<Signal> signals) {
            this.available = available;
            this.aiProbability = aiProbability;
            this.verdict = verdict == null ? Verdict.UNCERTAIN : verdict;
            this.model = model == null ? "" : model;
            this.type = type == null ? "" : type;
            this.note = note == null ? "" : note;
            this.signals = signals == null ? new ArrayList<>() : new ArrayList<>(signals);
        }

        static DetectionResult single(String type, Signal signal, String model) {
            List<Signal> one = new ArrayList<>();
            one.add(signal);
            double p = signal.aiProbability;
            // A single model must be extremely confident; otherwise abstain.
            Verdict v = p >= VERY_STRONG_AI ? Verdict.VERIFIED_AI
                    : p <= VERY_STRONG_REAL ? Verdict.VERIFIED_REAL : Verdict.UNCERTAIN;
            return new DetectionResult(true, p, v, model, type, "", one);
        }

        static DetectionResult consensus(String type, List<Signal> signals, String model) {
            if (signals == null || signals.isEmpty()) return unavailable("Δεν υπήρξαν διαθέσιμα detector signals");
            List<Double> vals = new ArrayList<>();
            int aiVotes = 0, realVotes = 0;
            boolean veryAi = false, veryReal = false;
            for (Signal s : signals) {
                vals.add(s.aiProbability);
                if (s.aiProbability >= STRONG_AI) aiVotes++;
                if (s.aiProbability <= STRONG_REAL) realVotes++;
                if (s.aiProbability >= VERY_STRONG_AI) veryAi = true;
                if (s.aiProbability <= VERY_STRONG_REAL) veryReal = true;
            }
            double p = median(vals);
            Verdict v = Verdict.UNCERTAIN;
            int n = signals.size();
            // Any extreme contradiction means abstain. Trustworthiness is more important
            // than forcing a result.
            if (veryAi && veryReal) {
                v = Verdict.UNCERTAIN;
            } else if (n >= 3) {
                if (aiVotes >= 2 && realVotes == 0 && p >= 0.65) v = Verdict.VERIFIED_AI;
                else if (realVotes >= 2 && aiVotes == 0 && p <= 0.35) v = Verdict.VERIFIED_REAL;
            } else if (n == 2) {
                if (aiVotes == 2) v = Verdict.VERIFIED_AI;
                else if (realVotes == 2) v = Verdict.VERIFIED_REAL;
            } else {
                v = p >= VERY_STRONG_AI ? Verdict.VERIFIED_AI
                        : p <= VERY_STRONG_REAL ? Verdict.VERIFIED_REAL : Verdict.UNCERTAIN;
            }
            return new DetectionResult(true, p, v, model, type, "", signals);
        }

        DetectionResult withSignal(Signal extra) {
            List<Signal> all = new ArrayList<>(signals);
            all.add(extra);
            return consensus(type, all, model + " + cloud verification");
        }

        double signal(String prefix) {
            for (Signal s : signals) if (s.name.startsWith(prefix)) return s.aiProbability;
            return Double.NaN;
        }

        static DetectionResult unavailable(String note) {
            return new DetectionResult(false, Double.NaN, Verdict.UNCERTAIN, "", "", note, new ArrayList<>());
        }

        String display() {
            if (!available) return note;
            int pct = (int) Math.round(aiProbability * 100.0);
            return "AI " + pct + "% • " + verdict.name();
        }
    }

    private static final class BertTokenizer {
        private final Map<String, Integer> vocab = new HashMap<>();
        private final int clsId;
        private final int sepId;
        private final int padId;
        private final int unkId;

        BertTokenizer(Context context, String assetPath) throws Exception {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(context.getAssets().open(assetPath)))) {
                String line;
                int id = 0;
                while ((line = br.readLine()) != null) vocab.put(line.trim(), id++);
            }
            clsId = id("[CLS]", 101);
            sepId = id("[SEP]", 102);
            padId = id("[PAD]", 0);
            unkId = id("[UNK]", 100);
        }

        Encoding encode(String text, int maxLength) {
            List<Integer> ids = new ArrayList<>();
            ids.add(clsId);
            for (String token : basicTokens(text)) {
                for (int piece : wordPiece(token)) {
                    if (ids.size() >= maxLength - 1) break;
                    ids.add(piece);
                }
                if (ids.size() >= maxLength - 1) break;
            }
            ids.add(sepId);
            long[] input = new long[maxLength];
            long[] mask = new long[maxLength];
            for (int i = 0; i < maxLength; i++) {
                if (i < ids.size()) {
                    input[i] = ids.get(i);
                    mask[i] = 1;
                } else {
                    input[i] = padId;
                    mask[i] = 0;
                }
            }
            return new Encoding(input, mask);
        }

        private List<String> basicTokens(String text) {
            String lower = stripAccents(text.toLowerCase(Locale.ROOT));
            List<String> out = new ArrayList<>();
            StringBuilder cur = new StringBuilder();
            for (int i = 0; i < lower.length(); i++) {
                char c = lower.charAt(i);
                if (Character.isLetterOrDigit(c)) {
                    cur.append(c);
                } else {
                    if (cur.length() > 0) {
                        out.add(cur.toString());
                        cur.setLength(0);
                    }
                    if (!Character.isWhitespace(c) && !Character.isISOControl(c)) out.add(String.valueOf(c));
                }
            }
            if (cur.length() > 0) out.add(cur.toString());
            return out;
        }

        private int[] wordPiece(String token) {
            if (token.length() > 100) return new int[]{unkId};
            if (vocab.containsKey(token)) return new int[]{vocab.get(token)};
            List<Integer> pieces = new ArrayList<>();
            int start = 0;
            while (start < token.length()) {
                int end = token.length();
                Integer found = null;
                int foundEnd = start;
                while (start < end) {
                    String sub = token.substring(start, end);
                    if (start > 0) sub = "##" + sub;
                    Integer v = vocab.get(sub);
                    if (v != null) {
                        found = v;
                        foundEnd = end;
                        break;
                    }
                    end--;
                }
                if (found == null) return new int[]{unkId};
                pieces.add(found);
                start = foundEnd;
            }
            int[] r = new int[pieces.size()];
            for (int i = 0; i < r.length; i++) r[i] = pieces.get(i);
            return r;
        }

        private int id(String token, int fallback) {
            Integer i = vocab.get(token);
            return i == null ? fallback : i;
        }

        private static String stripAccents(String s) {
            String n = Normalizer.normalize(s, Normalizer.Form.NFD);
            return n.replaceAll("\\p{M}+", "");
        }

        static final class Encoding {
            final long[] inputIds;
            final long[] attentionMask;
            Encoding(long[] inputIds, long[] attentionMask) {
                this.inputIds = inputIds;
                this.attentionMask = attentionMask;
            }
        }
    }
}
