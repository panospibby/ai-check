package com.panos.aiscreencheck;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CaptureService extends Service {
    public static final String ACTION_STOP = "com.panos.aiscreencheck.STOP";
    public static final String ACTION_SHOW_MENU = "com.panos.aiscreencheck.SHOW_MENU";
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_RESULT_DATA = "resultData";

    private static final int NOTIFICATION_ID = 42;
    private static final String CHANNEL_ID = "ai_screen_check_v4";
    private static final int AUDIO_SECONDS = 12;

    private static volatile boolean running = false;
    public static boolean isRunning() { return running; }

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService analysisExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService audioExecutor = Executors.newSingleThreadExecutor();
    private final ConcurrentLinkedQueue<FrameTask> frameTasks = new ConcurrentLinkedQueue<>();

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread captureThread;
    private Handler captureHandler;
    private TextRecognizer textRecognizer;
    private OnDeviceModels models;

    private WindowManager windowManager;
    private TextView bubble;
    private WindowManager.LayoutParams bubbleParams;
    private LinearLayout menu;
    private WindowManager.LayoutParams menuParams;
    private LinearLayout resultCard;
    private TextView resultTitle;
    private TextView resultBody;
    private WindowManager.LayoutParams resultParams;

    private volatile boolean shuttingDown = false;
    private volatile ScanSession activeSession;
    private Runnable autoHideResult;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        models = new OnDeviceModels(this);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopEverything();
            return START_NOT_STICKY;
        }
        if (intent != null && ACTION_SHOW_MENU.equals(intent.getAction())) {
            if (running && !shuttingDown) mainHandler.post(this::showMenu);
            return START_NOT_STICKY;
        }
        if (mediaProjection != null) return START_NOT_STICKY;
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent resultData = parcelableIntent(intent, EXTRA_RESULT_DATA);
        if (resultCode == 0 || resultData == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        startProjectionForeground(buildNotification("Floating AI ενεργό"));
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        mediaProjection = mpm.getMediaProjection(resultCode, resultData);
        if (mediaProjection == null) {
            stopEverything();
            return START_NOT_STICKY;
        }

        mediaProjection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { stopEverything(); }
        }, mainHandler);

        startCapturePipeline();
        showBubble();
        running = true;
        return START_NOT_STICKY;
    }

    @SuppressWarnings("deprecation")
    private static Intent parcelableIntent(Intent intent, String key) {
        if (Build.VERSION.SDK_INT >= 33) return intent.getParcelableExtra(key, Intent.class);
        return intent.getParcelableExtra(key);
    }

    private void startProjectionForeground(Notification notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            int types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                types |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            }
            startForeground(NOTIFICATION_ID, notification, types);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    @SuppressWarnings("deprecation")
    private void startCapturePipeline() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int sourceW = Math.max(1, dm.widthPixels);
        int sourceH = Math.max(1, dm.heightPixels);
        int captureW = Math.min(1080, sourceW);
        int captureH = Math.max(1, Math.round(sourceH * (captureW / (float) sourceW)));

        imageReader = ImageReader.newInstance(captureW, captureH, PixelFormat.RGBA_8888, 3);
        captureThread = new HandlerThread("ai-v4-capture");
        captureThread.start();
        captureHandler = new Handler(captureThread.getLooper());

        imageReader.setOnImageAvailableListener(reader -> {
            Image image = null;
            try {
                image = reader.acquireLatestImage();
                if (image == null || shuttingDown) return;
                FrameTask task = nextActiveTask();
                if (task == null) return;
                Bitmap bitmap = imageToBitmap(image);
                if (bitmap == null) {
                    showResult("AI CHECK", "Δεν μπόρεσε να ληφθεί εικόνα.", false);
                    return;
                }
                processFrame(task, bitmap);
            } catch (Exception e) {
                showResult("AI CHECK", "Capture error: " + shortMessage(e), false);
            } finally {
                if (image != null) image.close();
            }
        }, captureHandler);

        virtualDisplay = mediaProjection.createVirtualDisplay(
                "AI-Screen-Check-v4",
                captureW, captureH, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, captureHandler);
    }

    private FrameTask nextActiveTask() {
        FrameTask t;
        while ((t = frameTasks.poll()) != null) {
            if (t.session == activeSession && !t.session.cancelled) return t;
        }
        return null;
    }

    private void processFrame(FrameTask task, Bitmap bitmap) {
        switch (task.kind) {
            case IMAGE:
                analysisExecutor.execute(() -> {
                    try {
                        OnDeviceModels.DetectionResult r = models.image(bitmap);
                        if (task.session == activeSession && !task.session.cancelled) {
                            showDetection("ΕΙΚΟΝΑ", r, "Trained ONNX image model");
                        }
                    } catch (Exception e) {
                        showResult("ΕΙΚΟΝΑ", "Model error: " + shortMessage(e), false);
                    } finally {
                        if (!bitmap.isRecycled()) bitmap.recycle();
                    }
                });
                break;
            case TEXT:
                recognizeAndScoreText(task.session, bitmap);
                break;
            case VIDEO:
                analysisExecutor.execute(() -> {
                    try {
                        OnDeviceModels.DetectionResult r = models.image(bitmap);
                        task.session.addVideo(r);
                        updateVideoResult(task.session);
                    } catch (Exception e) {
                        task.session.addVideoError();
                        updateVideoResult(task.session);
                    } finally {
                        if (!bitmap.isRecycled()) bitmap.recycle();
                    }
                });
                break;
        }
    }

    private void recognizeAndScoreText(ScanSession session, Bitmap bitmap) {
        VisibleTextStore.Snapshot snapshot = VisibleTextStore.get();
        String base = snapshot.isFresh(12000L) ? snapshot.text : "";
        InputImage input = InputImage.fromBitmap(bitmap, 0);
        textRecognizer.process(input)
                .addOnSuccessListener(text -> {
                    String ocr = text == null ? "" : text.getText();
                    String combined = mergeText(base, ocr);
                    if (!bitmap.isRecycled()) bitmap.recycle();
                    analysisExecutor.execute(() -> {
                        try {
                            OnDeviceModels.DetectionResult r = models.text(combined);
                            showDetection("ΚΕΙΜΕΝΟ", r, "English trained text model");
                        } catch (Exception e) {
                            showResult("ΚΕΙΜΕΝΟ", "Model error: " + shortMessage(e), false);
                        }
                    });
                })
                .addOnFailureListener(e -> {
                    if (!bitmap.isRecycled()) bitmap.recycle();
                    analysisExecutor.execute(() -> {
                        try {
                            OnDeviceModels.DetectionResult r = models.text(base);
                            showDetection("ΚΕΙΜΕΝΟ", r, "English trained text model");
                        } catch (Exception ex) {
                            showResult("ΚΕΙΜΕΝΟ", "OCR/model error", false);
                        }
                    });
                });
    }

    private void startImageScan() {
        ScanSession s = newSession(ScanMode.IMAGE);
        hideMenu();
        showResult("ΕΙΚΟΝΑ", "Φόρτωση trained model και ανάλυση…", false);
        mainHandler.postDelayed(() -> enqueue(new FrameTask(FrameKind.IMAGE, s)), 250L);
    }

    private void startTextScan() {
        ScanSession s = newSession(ScanMode.TEXT);
        hideMenu();
        showResult("ΚΕΙΜΕΝΟ", "Διαβάζω το ορατό κείμενο…", false);
        mainHandler.postDelayed(() -> enqueue(new FrameTask(FrameKind.TEXT, s)), 250L);
    }

    private void startVideoScan() {
        ScanSession s = newSession(ScanMode.VIDEO);
        hideMenu();
        showResult("VIDEO", "Αναλύω 6 frames με trained image model… 0/6", false);
        for (int i = 0; i < 6; i++) {
            mainHandler.postDelayed(() -> enqueue(new FrameTask(FrameKind.VIDEO, s)), 250L + i * 900L);
        }
    }

    private void startMusicScan() {
        ScanSession s = newSession(ScanMode.MUSIC);
        hideMenu();
        showResult("ΜΟΥΣΙΚΗ", "Ακούω 12 δευτερόλεπτα…", false);
        startAudioScan(s);
    }

    private ScanSession newSession(ScanMode mode) {
        if (activeSession != null) activeSession.cancelled = true;
        frameTasks.clear();
        ScanSession s = new ScanSession(mode);
        activeSession = s;
        return s;
    }

    private void enqueue(FrameTask task) {
        if (task.session != activeSession || task.session.cancelled || shuttingDown) return;
        frameTasks.offer(task);
    }

    private void updateVideoResult(ScanSession session) {
        if (session != activeSession || session.cancelled) return;
        int done;
        List<Double> copy;
        synchronized (session) {
            done = session.videoDone;
            copy = new ArrayList<>(session.videoScores);
        }
        if (done < 6) {
            showResult("VIDEO", "Αναλύω frames… " + done + "/6", false);
            return;
        }
        if (copy.size() < 3) {
            showResult("VIDEO", "Δεν υπήρχαν αρκετά frames για ασφαλές αποτέλεσμα.", true);
            return;
        }
        Collections.sort(copy);
        int from = copy.size() >= 5 ? 1 : 0;
        int to = copy.size() >= 5 ? copy.size() - 1 : copy.size();
        double sum = 0.0;
        for (int i = from; i < to; i++) sum += copy.get(i);
        double p = sum / Math.max(1, to - from);
        OnDeviceModels.DetectionResult r = OnDeviceModels.DetectionResult.score(
                p, OnDeviceModels.VIDEO_THRESHOLD,
                "6-frame trimmed mean", "Video");
        showDetection("VIDEO", r, "6 sampled frames • trimmed mean");
    }

    private void startAudioScan(ScanSession session) {
        if (Build.VERSION.SDK_INT < 29) {
            showResult("ΜΟΥΣΙΚΗ", "Απαιτεί Android 10+.", true);
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            showResult("ΜΟΥΣΙΚΗ", "Δεν έχει δοθεί άδεια ήχου.", true);
            return;
        }

        audioExecutor.execute(() -> {
            AudioRecord record = null;
            try {
                final int sampleRate = 16000;
                final int channelMask = AudioFormat.CHANNEL_IN_MONO;
                final int encoding = AudioFormat.ENCODING_PCM_16BIT;
                int min = AudioRecord.getMinBufferSize(sampleRate, channelMask, encoding);
                if (min <= 0) min = 8192;

                AudioPlaybackCaptureConfiguration config =
                        new AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                                .build();

                AudioFormat format = new AudioFormat.Builder()
                        .setEncoding(encoding)
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelMask)
                        .build();

                record = new AudioRecord.Builder()
                        .setAudioFormat(format)
                        .setBufferSizeInBytes(Math.max(min * 2, 32768))
                        .setAudioPlaybackCaptureConfig(config)
                        .build();

                if (record.getState() != AudioRecord.STATE_INITIALIZED) {
                    showResult("ΜΟΥΣΙΚΗ", "Η εφαρμογή/συσκευή δεν επιτρέπει playback capture.", true);
                    return;
                }

                short[] samples = new short[sampleRate * AUDIO_SECONDS];
                short[] buffer = new short[Math.max(2048, min / 2)];
                int written = 0;
                record.startRecording();
                long deadline = System.currentTimeMillis() + AUDIO_SECONDS * 1000L + 1200L;
                while (written < samples.length && System.currentTimeMillis() < deadline
                        && !session.cancelled && !shuttingDown) {
                    int want = Math.min(buffer.length, samples.length - written);
                    int n = record.read(buffer, 0, want);
                    if (n > 0) {
                        System.arraycopy(buffer, 0, samples, written, n);
                        written += n;
                    }
                }
                try { record.stop(); } catch (Exception ignored) {}
                if (session.cancelled || shuttingDown) return;

                showResult("ΜΟΥΣΙΚΗ", "Ανάλυση spectral fingerprint…", false);
                OnDeviceModels.DetectionResult r = models.music(samples, written, sampleRate);
                showDetection("ΜΟΥΣΙΚΗ", r, "Suno/Udio spectral detector");
            } catch (SecurityException e) {
                showResult("ΜΟΥΣΙΚΗ", "Το app που παίζει ήχο μπλοκάρει playback capture.", true);
            } catch (Exception e) {
                showResult("ΜΟΥΣΙΚΗ", "Model/audio error: " + shortMessage(e), true);
            } finally {
                if (record != null) {
                    try { record.release(); } catch (Exception ignored) {}
                }
            }
        });
    }

    private void showDetection(String title, OnDeviceModels.DetectionResult r, String detail) {
        if (r == null) return;
        if (!r.available) {
            showResult(title, r.note, true);
            return;
        }
        int pct = (int) Math.round(r.aiProbability * 100.0);
        String verdict = r.ai ? "ΝΑΙ — πιθανό AI" : "ΟΧΙ — πιθανό πραγματικό/ανθρώπινο";
        showResult(title,
                "AI: " + pct + "%\n" + verdict + "\n\n" + detail,
                true);
    }

    private void showBubble() {
        if (bubble != null || shuttingDown) return;
        bubble = new TextView(this);
        bubble.setText("AI");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(17f);
        bubble.setTypeface(null, android.graphics.Typeface.BOLD);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xFF2D6CDF);
        circle.setStroke(dp(2), 0xAAFFFFFF);
        bubble.setBackground(circle);
        bubble.setElevation(dp(8));

        bubbleParams = overlayParams(dp(58), dp(58));
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        bubbleParams.x = Math.max(dp(6), dm.widthPixels - dp(72));
        bubbleParams.y = Math.max(dp(120), dm.heightPixels / 3);

        final int touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX(); downY = event.getRawY();
                        startX = bubbleParams.x; startY = bubbleParams.y; moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = Math.round(event.getRawX() - downX);
                        int dy = Math.round(event.getRawY() - downY);
                        if (Math.abs(dx) > touchSlop || Math.abs(dy) > touchSlop) moved = true;
                        if (moved) {
                            bubbleParams.x = clamp(startX + dx, 0, Math.max(0, getResources().getDisplayMetrics().widthPixels - dp(58)));
                            bubbleParams.y = clamp(startY + dy, dp(24), Math.max(dp(24), getResources().getDisplayMetrics().heightPixels - dp(90)));
                            try { windowManager.updateViewLayout(bubble, bubbleParams); } catch (Exception ignored) {}
                            if (menu != null) hideMenu();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) toggleMenu();
                        return true;
                    default:
                        return false;
                }
            }
        });

        try { windowManager.addView(bubble, bubbleParams); }
        catch (Exception e) { stopEverything(); }
    }

    private void toggleMenu() {
        if (menu == null) showMenu(); else hideMenu();
    }

    private void showMenu() {
        if (shuttingDown || bubble == null) return;
        hideMenu();
        menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setPadding(dp(8), dp(8), dp(8), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF21A1D23);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), 0xFF3D4655);
        menu.setBackground(bg);
        menu.setElevation(dp(10));

        menu.addView(menuButton("🖼  Εικόνα", this::startImageScan));
        menu.addView(menuButton("🎬  Video", this::startVideoScan));
        menu.addView(menuButton("🎵  Μουσική", this::startMusicScan));
        menu.addView(menuButton("📝  Κείμενο (EN)", this::startTextScan));
        menu.addView(menuButton("✕  Κλείσιμο", this::stopEverything));

        menuParams = overlayParams(dp(190), WindowManager.LayoutParams.WRAP_CONTENT);
        menuParams.gravity = Gravity.TOP | Gravity.START;
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int desiredX = bubbleParams.x - dp(198);
        if (desiredX < dp(4)) desiredX = Math.min(screenW - dp(194), bubbleParams.x + dp(64));
        menuParams.x = Math.max(dp(4), desiredX);
        menuParams.y = Math.max(dp(35), bubbleParams.y - dp(10));
        try { windowManager.addView(menu, menuParams); }
        catch (Exception ignored) { menu = null; }
    }

    private TextView menuButton(String label, Runnable action) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(15f);
        tv.setGravity(Gravity.CENTER_VERTICAL);
        tv.setPadding(dp(12), dp(11), dp(12), dp(11));
        tv.setOnClickListener(v -> action.run());
        return tv;
    }

    private void hideMenu() {
        if (menu == null) return;
        try { windowManager.removeView(menu); } catch (Exception ignored) {}
        menu = null;
        menuParams = null;
    }

    private void ensureResultCard() {
        if (resultCard != null) return;
        resultCard = new LinearLayout(this);
        resultCard.setOrientation(LinearLayout.VERTICAL);
        resultCard.setPadding(dp(14), dp(10), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF0181B21);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), 0xFF445064);
        resultCard.setBackground(bg);
        resultCard.setElevation(dp(8));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        resultTitle = new TextView(this);
        resultTitle.setTextColor(Color.WHITE);
        resultTitle.setTextSize(14f);
        resultTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        header.addView(resultTitle, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = new TextView(this);
        close.setText("✕");
        close.setTextColor(0xFFD0D4DB);
        close.setTextSize(17f);
        close.setGravity(Gravity.CENTER);
        close.setPadding(dp(10), dp(2), dp(2), dp(2));
        close.setOnClickListener(v -> hideResult());
        header.addView(close, new LinearLayout.LayoutParams(dp(38), dp(34)));
        resultCard.addView(header);

        resultBody = new TextView(this);
        resultBody.setTextColor(0xFFE5E8ED);
        resultBody.setTextSize(14f);
        resultBody.setLineSpacing(0f, 1.08f);
        resultCard.addView(resultBody);

        resultParams = overlayParams(dp(292), WindowManager.LayoutParams.WRAP_CONTENT);
        resultParams.gravity = Gravity.TOP | Gravity.END;
        resultParams.x = dp(8);
        resultParams.y = dp(54);
        try { windowManager.addView(resultCard, resultParams); }
        catch (Exception e) { resultCard = null; }
    }

    private void showResult(String title, String body, boolean autoHide) {
        mainHandler.post(() -> {
            if (shuttingDown) return;
            ensureResultCard();
            if (resultCard == null) return;
            resultTitle.setText(title);
            resultBody.setText(body);
            resultCard.setVisibility(View.VISIBLE);
            if (autoHideResult != null) mainHandler.removeCallbacks(autoHideResult);
            if (autoHide) {
                autoHideResult = this::hideResult;
                mainHandler.postDelayed(autoHideResult, 9000L);
            }
        });
    }

    private void hideResult() {
        if (autoHideResult != null) mainHandler.removeCallbacks(autoHideResult);
        autoHideResult = null;
        if (resultCard == null) return;
        try { windowManager.removeView(resultCard); } catch (Exception ignored) {}
        resultCard = null;
        resultTitle = null;
        resultBody = null;
        resultParams = null;
    }

    private WindowManager.LayoutParams overlayParams(int width, int height) {
        return new WindowManager.LayoutParams(
                width, height,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
    }

    private Notification buildNotification(String text) {
        Intent menuIntent = new Intent(this, CaptureService.class);
        menuIntent.setAction(ACTION_SHOW_MENU);
        PendingIntent menuPending = PendingIntent.getService(
                this, 11, menuIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(this, CaptureService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(
                this, 12, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        b.setContentTitle("AI Screen Check 4.0")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_search)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_more, "Menu", menuPending).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPending).build());
        return b.build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel c = new NotificationChannel(CHANNEL_ID, "AI Screen Check", NotificationManager.IMPORTANCE_LOW);
        c.setDescription("On-device AI detection");
        nm.createNotificationChannel(c);
    }

    private Bitmap imageToBitmap(Image image) {
        if (image.getPlanes().length == 0) return null;
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int rowPadding = rowStride - pixelStride * image.getWidth();
        int paddedWidth = image.getWidth() + Math.max(0, rowPadding / Math.max(1, pixelStride));
        Bitmap padded = Bitmap.createBitmap(paddedWidth, image.getHeight(), Bitmap.Config.ARGB_8888);
        padded.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(padded, 0, 0, image.getWidth(), image.getHeight());
        if (cropped != padded) padded.recycle();
        return cropped;
    }

    private String mergeText(String a, String b) {
        String x = a == null ? "" : a.trim();
        String y = b == null ? "" : b.trim();
        if (x.isEmpty()) return y;
        if (y.isEmpty()) return x;
        if (x.contains(y)) return x;
        if (y.contains(x)) return y;
        return x + "\n" + y;
    }

    private String shortMessage(Throwable e) {
        String s = e == null ? "unknown" : e.getMessage();
        if (s == null || s.trim().isEmpty()) s = e == null ? "unknown" : e.getClass().getSimpleName();
        s = s.replace('\n', ' ').trim();
        return s.length() > 110 ? s.substring(0, 110) + "…" : s;
    }

    private void stopEverything() {
        if (shuttingDown) return;
        shuttingDown = true;
        running = false;
        if (activeSession != null) activeSession.cancelled = true;
        frameTasks.clear();

        mainHandler.post(() -> {
            hideMenu();
            hideResult();
            if (bubble != null) {
                try { windowManager.removeView(bubble); } catch (Exception ignored) {}
                bubble = null;
            }
        });

        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) {}
        virtualDisplay = null;
        try { if (imageReader != null) imageReader.close(); } catch (Exception ignored) {}
        imageReader = null;
        try { if (mediaProjection != null) mediaProjection.stop(); } catch (Exception ignored) {}
        mediaProjection = null;
        if (captureThread != null) captureThread.quitSafely();
        captureThread = null;
        try { if (textRecognizer != null) textRecognizer.close(); } catch (Exception ignored) {}
        try { if (models != null) models.close(); } catch (Exception ignored) {}
        try { stopForeground(true); } catch (Exception ignored) {}
        stopSelf();
    }

    @Override
    public void onDestroy() {
        running = false;
        if (!shuttingDown) stopEverything();
        analysisExecutor.shutdownNow();
        audioExecutor.shutdownNow();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private enum FrameKind { IMAGE, TEXT, VIDEO }
    private enum ScanMode { IMAGE, TEXT, VIDEO, MUSIC }

    private static final class FrameTask {
        final FrameKind kind;
        final ScanSession session;
        FrameTask(FrameKind kind, ScanSession session) { this.kind = kind; this.session = session; }
    }

    private static final class ScanSession {
        final ScanMode mode;
        final List<Double> videoScores = new ArrayList<>();
        volatile boolean cancelled = false;
        int videoDone = 0;
        int videoErrors = 0;
        ScanSession(ScanMode mode) { this.mode = mode; }

        synchronized void addVideo(OnDeviceModels.DetectionResult r) {
            videoDone++;
            if (r != null && r.available) videoScores.add(r.aiProbability);
            else videoErrors++;
        }
        synchronized void addVideoError() { videoDone++; videoErrors++; }
    }
}
