package com.panos.aiscreencheck;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CaptureService extends Service {
    public static final String ACTION_STOP = "com.panos.aiscreencheck.STOP";
    public static final String ACTION_SMART_SCAN = "com.panos.aiscreencheck.SMART_SCAN";
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_RESULT_DATA = "resultData";

    private static final int NOTIFICATION_ID = 42;
    private static final String CHANNEL_ID = "ai_screen_check_local";
    private static final int AUDIO_SECONDS = 8;
    private static volatile boolean running = false;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService analysisExecutor = Executors.newFixedThreadPool(3);
    private final ExecutorService audioExecutor = Executors.newSingleThreadExecutor();
    private final ConcurrentLinkedQueue<FrameTask> frameTasks = new ConcurrentLinkedQueue<>();

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread captureThread;
    private Handler captureHandler;
    private TextRecognizer textRecognizer;

    private WindowManager windowManager;
    private TextView bubble;
    private WindowManager.LayoutParams bubbleParams;
    private TextView resultCard;
    private WindowManager.LayoutParams resultParams;

    private volatile ScanSession activeSession;
    private volatile boolean shuttingDown = false;

    public static boolean isRunning() {
        return running;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopEverything();
            return START_NOT_STICKY;
        }

        if (intent != null && ACTION_SMART_SCAN.equals(intent.getAction())) {
            if (mediaProjection != null && !shuttingDown) startSmartScan();
            return START_NOT_STICKY;
        }

        if (mediaProjection != null) return START_NOT_STICKY;
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent resultData = parcelableIntent(intent, EXTRA_RESULT_DATA);
        if (resultData == null || resultCode == 0) {
            stopSelf();
            return START_NOT_STICKY;
        }

        Notification notification = buildNotification("AI Screen Check 3.0 • Local");
        startProjectionForeground(notification);

        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        mediaProjection = mpm.getMediaProjection(resultCode, resultData);
        if (mediaProjection == null) {
            stopEverything();
            return START_NOT_STICKY;
        }

        mediaProjection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                stopEverything();
            }
        }, mainHandler);

        startCapturePipeline();
        showBubble();
        running = true;

        // One-button behavior: after permission is granted, run the first scan automatically.
        mainHandler.postDelayed(this::startSmartScan, 700L);
        return START_NOT_STICKY;
    }

    private void startProjectionForeground(Notification notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            int types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                types |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            }
            startForeground(NOTIFICATION_ID, notification, types);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    @SuppressWarnings("deprecation")
    private void startCapturePipeline() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int sourceW = Math.max(1, dm.widthPixels);
        int sourceH = Math.max(1, dm.heightPixels);
        int captureW = Math.min(900, sourceW);
        int captureH = Math.max(1, Math.round(sourceH * (captureW / (float) sourceW)));
        int density = dm.densityDpi;

        imageReader = ImageReader.newInstance(captureW, captureH, PixelFormat.RGBA_8888, 3);
        captureThread = new HandlerThread("ai-screen-capture");
        captureThread.start();
        captureHandler = new Handler(captureThread.getLooper());

        imageReader.setOnImageAvailableListener(reader -> {
            Image image = null;
            try {
                image = reader.acquireLatestImage();
                if (image == null || shuttingDown) return;

                FrameTask task = nextActiveTask();
                if (task == null) return;

                Bitmap bitmap = imageToBitmap(image);
                if (bitmap == null) {
                    updateLine(task.session, task.kind == FrameKind.SMART ? "Εικόνα" : "Video", "capture failed");
                    return;
                }
                processFrameTask(task, bitmap);
            } catch (Exception e) {
                ScanSession s = activeSession;
                if (s != null) updateLine(s, "Εικόνα", "capture error");
            } finally {
                if (image != null) image.close();
            }
        }, captureHandler);

        virtualDisplay = mediaProjection.createVirtualDisplay(
                "AI-Screen-Check-Local",
                captureW,
                captureH,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null,
                captureHandler
        );
    }

    private FrameTask nextActiveTask() {
        FrameTask task;
        while ((task = frameTasks.poll()) != null) {
            if (task.session == activeSession && !task.session.cancelled) return task;
        }
        return null;
    }

    private void processFrameTask(FrameTask task, Bitmap bitmap) {
        if (task.kind == FrameKind.SMART) handleSmartFrame(task.session, bitmap);
        else handleVideoFrame(task, bitmap);
    }

    private void handleSmartFrame(ScanSession session, Bitmap bitmap) {
        Bitmap visualCopy = bitmap.copy(Bitmap.Config.ARGB_8888, false);
        analysisExecutor.execute(() -> {
            try {
                LocalScore visual = LocalAiDetector.scoreImage(visualCopy);
                updateScore(session, "Εικόνα", visual);
            } finally {
                if (!visualCopy.isRecycled()) visualCopy.recycle();
            }
        });

        VisibleTextStore.Snapshot snapshot = VisibleTextStore.get();
        String accessibilityText = snapshot.isFresh(12000L) ? snapshot.text : "";
        recognizeText(session, bitmap, accessibilityText);
    }

    private void recognizeText(ScanSession session, Bitmap bitmap, String baseText) {
        InputImage input = InputImage.fromBitmap(bitmap, 0);
        textRecognizer.process(input)
                .addOnSuccessListener(text -> {
                    String ocr = text == null ? "" : text.getText();
                    String combined = mergeText(baseText, ocr);
                    if (!bitmap.isRecycled()) bitmap.recycle();
                    analysisExecutor.execute(() -> {
                        LocalScore result = LocalAiDetector.scoreText(combined);
                        updateScore(session, "Κείμενο", result);
                    });
                })
                .addOnFailureListener(e -> {
                    if (!bitmap.isRecycled()) bitmap.recycle();
                    analysisExecutor.execute(() -> {
                        LocalScore result = LocalAiDetector.scoreText(baseText);
                        updateScore(session, "Κείμενο", result);
                    });
                });
    }

    private void handleVideoFrame(FrameTask task, Bitmap bitmap) {
        analysisExecutor.execute(() -> {
            try {
                LocalScore score = LocalAiDetector.scoreImage(bitmap);
                task.session.addVideoScore(score.aiProbability, task.total);
            } catch (Exception e) {
                task.session.addVideoError(task.total);
            } finally {
                if (!bitmap.isRecycled()) bitmap.recycle();
                renderSession(task.session);
            }
        });
    }

    private void startSmartScan() {
        if (mediaProjection == null || shuttingDown) return;
        if (activeSession != null) activeSession.cancelled = true;
        frameTasks.clear();

        ScanSession s = new ScanSession();
        s.lines.put("Κείμενο", "διαβάζω οθόνη…");
        s.lines.put("Εικόνα", "αναλύω εικόνα…");
        s.lines.put("Video", "δειγματοληψία 5 frames…");
        s.lines.put("Μουσική", Build.VERSION.SDK_INT >= 29 ? "ακούω 8 δευτερόλεπτα…" : "απαιτεί Android 10+");
        activeSession = s;
        renderSession(s);

        enqueueFrame(new FrameTask(FrameKind.SMART, s, 1, 1));
        for (int i = 0; i < 5; i++) {
            final int index = i + 1;
            mainHandler.postDelayed(
                    () -> enqueueFrame(new FrameTask(FrameKind.VIDEO, s, index, 5)),
                    650L + i * 800L);
        }
        startAudioScan(s);
    }

    private void startAudioScan(ScanSession session) {
        if (Build.VERSION.SDK_INT < 29) {
            updateUnavailable(session, "Μουσική", "Android 10+");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            updateUnavailable(session, "Μουσική", "δεν δόθηκε άδεια ήχου");
            return;
        }

        audioExecutor.execute(() -> {
            AudioRecord record = null;
            try {
                final int sampleRate = 16000;
                final int channelMask = AudioFormat.CHANNEL_IN_MONO;
                final int encoding = AudioFormat.ENCODING_PCM_16BIT;
                int min = AudioRecord.getMinBufferSize(sampleRate, channelMask, encoding);
                if (min <= 0) min = 8192;

                AudioPlaybackCaptureConfiguration config =
                        new AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                                .build();

                AudioFormat format = new AudioFormat.Builder()
                        .setEncoding(encoding)
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelMask)
                        .build();

                record = new AudioRecord.Builder()
                        .setAudioFormat(format)
                        .setBufferSizeInBytes(Math.max(min * 2, 16384))
                        .setAudioPlaybackCaptureConfig(config)
                        .build();

                if (record.getState() != AudioRecord.STATE_INITIALIZED) {
                    updateUnavailable(session, "Μουσική", "audio capture unavailable");
                    return;
                }

                short[] samples = new short[sampleRate * AUDIO_SECONDS];
                short[] buffer = new short[Math.max(2048, min / 2)];
                int written = 0;
                record.startRecording();
                long deadline = System.currentTimeMillis() + AUDIO_SECONDS * 1000L + 600L;

                while (written < samples.length
                        && System.currentTimeMillis() < deadline
                        && !session.cancelled
                        && !shuttingDown) {
                    int want = Math.min(buffer.length, samples.length - written);
                    int n = record.read(buffer, 0, want);
                    if (n > 0) {
                        System.arraycopy(buffer, 0, samples, written, n);
                        written += n;
                    }
                }

                try { record.stop(); } catch (Exception ignored) {}

                if (session.cancelled || shuttingDown) return;
                LocalScore music = LocalAiDetector.scoreMusic(samples, written, sampleRate);
                updateScore(session, "Μουσική", music);
            } catch (SecurityException e) {
                updateUnavailable(session, "Μουσική", "η εφαρμογή μπλοκάρει capture ήχου");
            } catch (Exception e) {
                updateUnavailable(session, "Μουσική", "audio unavailable");
            } finally {
                if (record != null) {
                    try { record.release(); } catch (Exception ignored) {}
                }
            }
        });
    }

    private void enqueueFrame(FrameTask task) {
        if (task.session.cancelled || task.session != activeSession) return;
        frameTasks.offer(task);
    }

    private void updateScore(ScanSession session, String key, LocalScore score) {
        if (session == null || session.cancelled || session != activeSession) return;
        synchronized (session) {
            if (score.available) {
                session.scores.put(key, score.aiProbability);
                session.lines.put(key, formatScore(score));
            } else {
                session.lines.put(key, score.note);
            }
        }
        renderSession(session);
    }

    private void updateUnavailable(ScanSession session, String key, String message) {
        if (session == null || session.cancelled || session != activeSession) return;
        synchronized (session) {
            session.lines.put(key, message);
        }
        renderSession(session);
    }

    private void updateLine(ScanSession session, String key, String message) {
        if (session == null || session.cancelled || session != activeSession) return;
        synchronized (session) {
            session.lines.put(key, message);
        }
        renderSession(session);
    }

    private String formatScore(LocalScore score) {
        int pct = (int) Math.round(score.aiProbability * 100.0);
        String verdict;
        if (score.aiProbability >= 0.67) verdict = "πιθανό AI";
        else if (score.aiProbability <= 0.33) verdict = "πιθανό ανθρώπινο/real";
        else verdict = "αβέβαιο";
        String confidence = score.confidence < 0.45 ? " • χαμηλή βεβαιότητα" : "";
        String note = score.note == null || score.note.isEmpty() ? "" : " • " + score.note;
        return "AI " + pct + "% • " + verdict + confidence + note;
    }

    private void renderSession(ScanSession session) {
        if (session == null || session.cancelled || session != activeSession) return;
        mainHandler.post(() -> {
            if (session.cancelled || session != activeSession || shuttingDown) return;
            ensureResultCard();
            StringBuilder sb = new StringBuilder();
            sb.append("AI CHECK\n\n");
            synchronized (session) {
                for (Map.Entry<String, String> entry : session.lines.entrySet()) {
                    sb.append(entry.getKey()).append(":  ").append(entry.getValue()).append('\n');
                }
                if (session.scores.size() >= 2) {
                    double weighted = 0.0;
                    double weights = 0.0;
                    for (Map.Entry<String, Double> e : session.scores.entrySet()) {
                        double w = "Εικόνα".equals(e.getKey()) ? 0.8 : 1.0;
                        if ("Video".equals(e.getKey())) w = 0.9;
                        weighted += e.getValue() * w;
                        weights += w;
                    }
                    double overall = weights == 0 ? 0.5 : weighted / weights;
                    int pct = (int) Math.round(overall * 100.0);
                    String verdict = overall >= 0.67 ? "ΠΙΘΑΝΟ AI" : overall <= 0.33 ? "ΠΙΘΑΝΟ REAL/HUMAN" : "ΑΒΕΒΑΙΟ";
                    sb.append("\nΣΥΝΟΛΟ: AI ").append(pct).append("% • ").append(verdict);
                }
            }
            sb.append("\n\nLocal forensic estimate • όχι απόδειξη");
            resultCard.setText(sb.toString());
            resultCard.setVisibility(View.VISIBLE);
        });
    }

    private void ensureResultCard() {
        if (resultCard != null) return;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        resultCard = new TextView(this);
        resultCard.setTextColor(Color.WHITE);
        resultCard.setTextSize(14f);
        resultCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        resultCard.setGravity(Gravity.START);
        resultCard.setLineSpacing(0f, 1.06f);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xEE171A20);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), 0xFF3C4452);
        resultCard.setBackground(bg);

        resultParams = new WindowManager.LayoutParams(
                dp(330), WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        resultParams.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        resultParams.y = dp(80);
        try {
            windowManager.addView(resultCard, resultParams);
        } catch (Exception ignored) {
            resultCard = null;
        }
    }

    private void showBubble() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        bubble = new TextView(this);
        bubble.setText("AI");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(18f);
        bubble.setTypeface(null, android.graphics.Typeface.BOLD);
        bubble.setGravity(Gravity.CENTER);

        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xFF2D6CDF);
        circle.setStroke(dp(2), 0xAAFFFFFF);
        bubble.setBackground(circle);
        bubble.setElevation(dp(8));

        bubbleParams = new WindowManager.LayoutParams(
                dp(64), dp(64),
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        bubbleParams.x = Math.max(dp(8), dm.widthPixels - dp(82));
        bubbleParams.y = Math.max(dp(120), dm.heightPixels / 3);

        final int touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downRawX;
            float downRawY;
            int startX;
            int startY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        startX = bubbleParams.x;
                        startY = bubbleParams.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = Math.round(event.getRawX() - downRawX);
                        int dy = Math.round(event.getRawY() - downRawY);
                        if (Math.abs(dx) > touchSlop || Math.abs(dy) > touchSlop) moved = true;
                        if (moved) {
                            bubbleParams.x = startX + dx;
                            bubbleParams.y = startY + dy;
                            try { windowManager.updateViewLayout(bubble, bubbleParams); } catch (Exception ignored) {}
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            bubble.setText("…");
                            startSmartScan();
                            mainHandler.postDelayed(() -> {
                                if (bubble != null) bubble.setText("AI");
                            }, 900L);
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });

        try {
            windowManager.addView(bubble, bubbleParams);
        } catch (Exception e) {
            stopEverything();
        }
    }

    private Notification buildNotification(String text) {
        Intent scanIntent = new Intent(this, CaptureService.class);
        scanIntent.setAction(ACTION_SMART_SCAN);
        PendingIntent scanPending = PendingIntent.getService(
                this, 11, scanIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(this, CaptureService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(
                this, 12, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        builder.setContentTitle("AI Screen Check 3.0")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_search)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_search, "AI CHECK", scanPending).build())
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPending).build());
        return builder.build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "AI Screen Check", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Floating local AI detector");
        nm.createNotificationChannel(channel);
    }

    private Bitmap imageToBitmap(Image image) {
        if (image.getPlanes().length == 0) return null;
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int rowPadding = rowStride - pixelStride * image.getWidth();
        int paddedWidth = image.getWidth() + Math.max(0, rowPadding / Math.max(1, pixelStride));
        Bitmap padded = Bitmap.createBitmap(paddedWidth, image.getHeight(), Bitmap.Config.ARGB_8888);
        padded.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(padded, 0, 0, image.getWidth(), image.getHeight());
        if (cropped != padded) padded.recycle();
        return cropped;
    }

    private String mergeText(String a, String b) {
        String aa = a == null ? "" : a.trim();
        String bb = b == null ? "" : b.trim();
        if (aa.isEmpty()) return bb;
        if (bb.isEmpty()) return aa;
        if (aa.contains(bb)) return aa;
        if (bb.contains(aa)) return bb;
        return aa + "\n" + bb;
    }

    @SuppressWarnings("deprecation")
    private Intent parcelableIntent(Intent source, String key) {
        if (Build.VERSION.SDK_INT >= 33) return source.getParcelableExtra(key, Intent.class);
        return source.getParcelableExtra(key);
    }

    private void stopEverything() {
        if (shuttingDown) return;
        shuttingDown = true;
        running = false;
        if (activeSession != null) activeSession.cancelled = true;
        frameTasks.clear();

        mainHandler.post(() -> {
            if (windowManager != null && bubble != null) {
                try { windowManager.removeView(bubble); } catch (Exception ignored) {}
            }
            if (windowManager != null && resultCard != null) {
                try { windowManager.removeView(resultCard); } catch (Exception ignored) {}
            }
            bubble = null;
            resultCard = null;
        });

        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) {}
        virtualDisplay = null;
        try { if (imageReader != null) imageReader.close(); } catch (Exception ignored) {}
        imageReader = null;
        try { if (mediaProjection != null) mediaProjection.stop(); } catch (Exception ignored) {}
        mediaProjection = null;
        if (captureThread != null) captureThread.quitSafely();
        captureThread = null;
        try { if (textRecognizer != null) textRecognizer.close(); } catch (Exception ignored) {}
        try { stopForeground(true); } catch (Exception ignored) {}
        stopSelf();
    }

    @Override
    public void onDestroy() {
        running = false;
        if (!shuttingDown) stopEverything();
        analysisExecutor.shutdownNow();
        audioExecutor.shutdownNow();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private enum FrameKind { SMART, VIDEO }

    private static final class FrameTask {
        final FrameKind kind;
        final ScanSession session;
        final int index;
        final int total;

        FrameTask(FrameKind kind, ScanSession session, int index, int total) {
            this.kind = kind;
            this.session = session;
            this.index = index;
            this.total = total;
        }
    }

    private final class ScanSession {
        final LinkedHashMap<String, String> lines = new LinkedHashMap<>();
        final LinkedHashMap<String, Double> scores = new LinkedHashMap<>();
        volatile boolean cancelled = false;
        int videoDone = 0;
        int videoErrors = 0;
        double videoTotal = 0.0;

        synchronized void addVideoScore(double score, int expected) {
            if (cancelled || this != activeSession) return;
            videoTotal += score;
            videoDone++;
            double average = videoTotal / Math.max(1, videoDone);
            scores.put("Video", average);
            if (videoDone >= expected) {
                LocalScore result = new LocalScore(true, average, 0.42,
                        "μέσος όρος " + videoDone + " frames");
                lines.put("Video", formatScore(result));
            } else {
                lines.put("Video", "AI " + Math.round(average * 100.0) + "% • " + videoDone + "/" + expected + " frames");
            }
        }

        synchronized void addVideoError(int expected) {
            if (cancelled || this != activeSession) return;
            videoErrors++;
            videoDone++;
            if (videoDone >= expected && !scores.containsKey("Video")) {
                lines.put("Video", "δεν μπόρεσε να αναλυθεί");
            }
        }
    }

    private static final class LocalScore {
        final boolean available;
        final double aiProbability;
        final double confidence;
        final String note;

        LocalScore(boolean available, double aiProbability, double confidence, String note) {
            this.available = available;
            this.aiProbability = clamp(aiProbability, 0.0, 1.0);
            this.confidence = clamp(confidence, 0.0, 1.0);
            this.note = note == null ? "" : note;
        }
    }

    /**
     * Offline, model-free forensic baseline. It never uploads content.
     * Scores are deliberately confidence-capped because provenance detection is probabilistic.
     */
    private static final class LocalAiDetector {
        private static final Pattern WORD = Pattern.compile("[\\p{L}\\p{M}']+");
        private static final Pattern SENTENCE = Pattern.compile("[^.!?;…]+[.!?;…]?");

        private static LocalScore scoreText(String input) {
            String text = input == null ? "" : input.replaceAll("\\s+", " ").trim();
            if (text.length() < 90) {
                return new LocalScore(false, 0.5, 0.1,
                        "λίγο κείμενο • χρειάζονται ~90+ χαρακτήρες");
            }

            List<String> words = new ArrayList<>();
            Matcher wm = WORD.matcher(text.toLowerCase(Locale.ROOT));
            while (wm.find()) words.add(wm.group());
            if (words.size() < 18) {
                return new LocalScore(false, 0.5, 0.1,
                        "λίγες λέξεις για αξιόπιστο text check");
            }

            List<Integer> sentenceLengths = new ArrayList<>();
            Matcher sm = SENTENCE.matcher(text);
            while (sm.find()) {
                Matcher sw = WORD.matcher(sm.group());
                int c = 0;
                while (sw.find()) c++;
                if (c > 0) sentenceLengths.add(c);
            }

            double wordMean = 0.0;
            for (String w : words) wordMean += w.length();
            wordMean /= words.size();
            double wordVar = 0.0;
            for (String w : words) {
                double d = w.length() - wordMean;
                wordVar += d * d;
            }
            double wordStd = Math.sqrt(wordVar / Math.max(1, words.size()));

            double sentenceCv = 1.0;
            if (sentenceLengths.size() >= 3) {
                double mean = 0.0;
                for (int v : sentenceLengths) mean += v;
                mean /= sentenceLengths.size();
                double var = 0.0;
                for (int v : sentenceLengths) {
                    double d = v - mean;
                    var += d * d;
                }
                sentenceCv = Math.sqrt(var / sentenceLengths.size()) / Math.max(1.0, mean);
            }

            java.util.HashSet<String> unique = new java.util.HashSet<>(words);
            double ttr = unique.size() / (double) words.size();

            java.util.HashMap<String, Integer> trigrams = new java.util.HashMap<>();
            int repeatedTri = 0;
            for (int i = 0; i + 2 < words.size(); i++) {
                String tri = words.get(i) + " " + words.get(i + 1) + " " + words.get(i + 2);
                int n = trigrams.containsKey(tri) ? trigrams.get(tri) + 1 : 1;
                trigrams.put(tri, n);
                if (n == 2) repeatedTri++;
            }
            double repeatRate = repeatedTri / (double) Math.max(1, words.size() - 2);

            String lower = text.toLowerCase(Locale.ROOT);
            String[] aiPhrases = {
                    "in conclusion", "overall", "it is important to", "it is worth noting",
                    "furthermore", "moreover", "delve into", "in today's",
                    "συνοψίζοντας", "εν κατακλείδι", "είναι σημαντικό να", "αξίζει να σημειωθεί",
                    "επιπλέον", "παράλληλα", "σε γενικές γραμμές"
            };
            int phraseHits = 0;
            for (String p : aiPhrases) if (lower.contains(p)) phraseHits++;

            int personal = countAny(lower, new String[]{
                    " i ", " i'm ", " my ", " me ", "lol", "haha", "😂", "🤣", "ρε ", "εγώ", "μου ", "μαλακ"
            });

            double score = 0.50;
            if (sentenceCv < 0.28) score += 0.11;
            else if (sentenceCv > 0.75) score -= 0.08;
            if (wordStd < 2.15) score += 0.05;
            if (ttr < 0.43) score += 0.07;
            else if (ttr > 0.68) score -= 0.05;
            score += Math.min(0.12, repeatRate * 1.8);
            score += Math.min(0.12, phraseHits * 0.035);
            score -= Math.min(0.10, personal * 0.025);

            // Keep heuristic text scores away from false certainty.
            score = clamp(score, 0.18, 0.82);
            double confidence = clamp(0.30 + text.length() / 1800.0, 0.30, 0.58);
            return new LocalScore(true, score, confidence, "stylometry");
        }

        private static int countAny(String text, String[] needles) {
            int hits = 0;
            for (String n : needles) if (text.contains(n)) hits++;
            return hits;
        }

        private static LocalScore scoreImage(Bitmap source) {
            if (source == null || source.isRecycled()) {
                return new LocalScore(false, 0.5, 0.0, "no image");
            }

            int sw = source.getWidth();
            int sh = source.getHeight();
            int left = Math.max(0, Math.round(sw * 0.06f));
            int top = Math.max(0, Math.round(sh * 0.08f));
            int cw = Math.max(1, Math.round(sw * 0.88f));
            int ch = Math.max(1, Math.round(sh * 0.80f));
            if (left + cw > sw) cw = sw - left;
            if (top + ch > sh) ch = sh - top;

            Bitmap crop = Bitmap.createBitmap(source, left, top, cw, ch);
            Bitmap small = Bitmap.createScaledBitmap(crop, 192, 192, true);
            if (crop != source) crop.recycle();

            final int w = small.getWidth();
            final int h = small.getHeight();
            int[] pixels = new int[w * h];
            small.getPixels(pixels, 0, w, 0, 0, w, h);
            small.recycle();

            double[] lum = new double[w * h];
            int[] hist = new int[4096];
            int clipped = 0;
            for (int i = 0; i < pixels.length; i++) {
                int c = pixels[i];
                int r = Color.red(c);
                int g = Color.green(c);
                int b = Color.blue(c);
                lum[i] = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0;
                hist[((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4)]++;
                if (r < 3 || g < 3 || b < 3 || r > 252 || g > 252 || b > 252) clipped++;
            }

            double entropy = 0.0;
            for (int count : hist) {
                if (count == 0) continue;
                double p = count / (double) pixels.length;
                entropy -= p * Math.log(p);
            }
            entropy /= Math.log(hist.length);

            double edgeSum = 0.0;
            double lapSum = 0.0;
            double[] blockLap = new double[16];
            int[] blockCount = new int[16];
            int n = 0;
            for (int y = 1; y < h - 1; y++) {
                for (int x = 1; x < w - 1; x++) {
                    int idx = y * w + x;
                    double gx = lum[idx + 1] - lum[idx - 1];
                    double gy = lum[idx + w] - lum[idx - w];
                    edgeSum += Math.sqrt(gx * gx + gy * gy);
                    double lap = Math.abs(4 * lum[idx] - lum[idx - 1] - lum[idx + 1] - lum[idx - w] - lum[idx + w]);
                    lapSum += lap;
                    int bx = Math.min(3, x * 4 / w);
                    int by = Math.min(3, y * 4 / h);
                    int bi = by * 4 + bx;
                    blockLap[bi] += lap;
                    blockCount[bi]++;
                    n++;
                }
            }
            double edge = edgeSum / Math.max(1, n);
            double lap = lapSum / Math.max(1, n);

            double blockMean = 0.0;
            for (int i = 0; i < 16; i++) {
                if (blockCount[i] > 0) blockLap[i] /= blockCount[i];
                blockMean += blockLap[i];
            }
            blockMean /= 16.0;
            double blockVar = 0.0;
            for (double v : blockLap) {
                double d = v - blockMean;
                blockVar += d * d;
            }
            double noiseCv = Math.sqrt(blockVar / 16.0) / Math.max(0.0001, blockMean);
            double clipRate = clipped / (double) pixels.length;

            double score = 0.50;
            if (noiseCv < 0.33) score += 0.12;
            else if (noiseCv > 0.95) score -= 0.08;
            if (entropy > 0.70) score += 0.07;
            else if (entropy < 0.47) score -= 0.05;
            if (lap < 0.055) score += 0.08;
            else if (lap > 0.16) score -= 0.06;
            if (clipRate < 0.015) score += 0.04;
            else if (clipRate > 0.12) score -= 0.04;
            if (edge > 0.07 && edge < 0.18) score += 0.03;

            score = clamp(score, 0.15, 0.85);
            return new LocalScore(true, score, 0.43, "visual forensics");
        }

        private static LocalScore scoreMusic(short[] samples, int length, int sampleRate) {
            if (samples == null || length < sampleRate * 2) {
                return new LocalScore(false, 0.5, 0.0, "πολύ μικρό audio sample");
            }

            double rms = 0.0;
            for (int i = 0; i < length; i++) {
                double v = samples[i] / 32768.0;
                rms += v * v;
            }
            rms = Math.sqrt(rms / length);
            if (rms < 0.0035) {
                return new LocalScore(false, 0.5, 0.0,
                        "δεν καταγράφηκε ήχος • ίσως η εφαρμογή μπλοκάρει playback capture");
            }

            final int fftSize = 4096;
            final int hop = 2048;
            final int minBin = Math.max(1, (int) Math.floor(1000.0 * fftSize / sampleRate));
            final int maxBin = Math.min(fftSize / 2 - 1, (int) Math.ceil(8000.0 * fftSize / sampleRate));
            if (maxBin <= minBin + 20) {
                return new LocalScore(false, 0.5, 0.0, "audio format unsupported");
            }

            double[] spectrum = new double[maxBin - minBin + 1];
            int frames = 0;
            double[] re = new double[fftSize];
            double[] im = new double[fftSize];

            for (int start = 0; start + fftSize <= length; start += hop) {
                for (int i = 0; i < fftSize; i++) {
                    double window = 0.5 - 0.5 * Math.cos(2.0 * Math.PI * i / (fftSize - 1));
                    re[i] = (samples[start + i] / 32768.0) * window;
                    im[i] = 0.0;
                }
                fft(re, im);
                for (int b = minBin; b <= maxBin; b++) {
                    double mag = Math.hypot(re[b], im[b]);
                    spectrum[b - minBin] += Math.log1p(mag);
                }
                frames++;
                if (frames >= 48) break;
            }
            if (frames < 3) return new LocalScore(false, 0.5, 0.0, "λίγα audio frames");
            for (int i = 0; i < spectrum.length; i++) spectrum[i] /= frames;

            // Remove slow spectral envelope: fakeprint-like residual.
            double[] residual = new double[spectrum.length];
            int radius = 7;
            for (int i = 0; i < spectrum.length; i++) {
                int a = Math.max(0, i - radius);
                int b = Math.min(spectrum.length - 1, i + radius);
                double mean = 0.0;
                for (int j = a; j <= b; j++) mean += spectrum[j];
                mean /= (b - a + 1);
                residual[i] = spectrum[i] - mean;
            }

            double mean = 0.0;
            for (double v : residual) mean += v;
            mean /= residual.length;
            double var = 0.0;
            for (double v : residual) {
                double d = v - mean;
                var += d * d;
            }
            double std = Math.sqrt(var / residual.length) + 1e-9;

            int peaks = 0;
            for (int i = 1; i + 1 < residual.length; i++) {
                if (residual[i] > residual[i - 1]
                        && residual[i] > residual[i + 1]
                        && residual[i] > mean + 1.45 * std) peaks++;
            }
            double peakRatio = peaks / (double) residual.length;

            double bestCorr = 0.0;
            int maxLag = Math.min(220, residual.length / 3);
            for (int lag = 4; lag <= maxLag; lag++) {
                double num = 0.0;
                double da = 0.0;
                double db = 0.0;
                for (int i = 0; i + lag < residual.length; i++) {
                    double a = residual[i] - mean;
                    double b = residual[i + lag] - mean;
                    num += a * b;
                    da += a * a;
                    db += b * b;
                }
                double corr = num / Math.sqrt(Math.max(1e-12, da * db));
                if (corr > bestCorr) bestCorr = corr;
            }

            double periodic = clamp((bestCorr - 0.10) / 0.38, 0.0, 1.0);
            double peaky = clamp((peakRatio - 0.018) / 0.075, 0.0, 1.0);
            double score = 0.20 + periodic * 0.58 + peaky * 0.22;
            score = clamp(score, 0.08, 0.92);
            return new LocalScore(true, score, 0.48, "spectral fakeprint estimate");
        }

        private static void fft(double[] re, double[] im) {
            int n = re.length;
            for (int i = 1, j = 0; i < n; i++) {
                int bit = n >> 1;
                for (; (j & bit) != 0; bit >>= 1) j ^= bit;
                j ^= bit;
                if (i < j) {
                    double tr = re[i]; re[i] = re[j]; re[j] = tr;
                    double ti = im[i]; im[i] = im[j]; im[j] = ti;
                }
            }
            for (int len = 2; len <= n; len <<= 1) {
                double angle = -2.0 * Math.PI / len;
                double wLenR = Math.cos(angle);
                double wLenI = Math.sin(angle);
                for (int i = 0; i < n; i += len) {
                    double wr = 1.0;
                    double wi = 0.0;
                    for (int j = 0; j < len / 2; j++) {
                        int u = i + j;
                        int v = i + j + len / 2;
                        double vr = re[v] * wr - im[v] * wi;
                        double vi = re[v] * wi + im[v] * wr;
                        double ur = re[u];
                        double ui = im[u];
                        re[u] = ur + vr;
                        im[u] = ui + vi;
                        re[v] = ur - vr;
                        im[v] = ui - vi;
                        double nextWr = wr * wLenR - wi * wLenI;
                        wi = wr * wLenI + wi * wLenR;
                        wr = nextWr;
                    }
                }
            }
        }
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }
}
